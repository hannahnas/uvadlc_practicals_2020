# Assignment 2
 
You can find all neccessary instructions in **assignment_2.pdf**

## Updates:
Line 78 in train.py changed to: config.num_classes = 2
